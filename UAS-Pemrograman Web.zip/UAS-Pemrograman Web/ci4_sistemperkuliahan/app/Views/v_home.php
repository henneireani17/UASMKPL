<div class="row">
    <div class="col-sm-12">
        <div class="text-center">
            <h1><b>Sistem Perkuliahan</b></h1>
        </div>
    </div>
    <div class="col-sm-12">

        <img class="img-responsive pad" src="<?= base_url('gambar/logo its.png') ?>" alt="Photo">

    </div>

</div>